package Lab6.ex2;

public class Entry {
    public Key key;
    public Value value;

    public Entry(Key k, Value v) {
        this.key = k;
        this.value = v;
    }
}
