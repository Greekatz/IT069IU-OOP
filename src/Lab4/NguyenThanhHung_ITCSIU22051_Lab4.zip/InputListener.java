package Lab4;
import javax.swing.JOptionPane;
import javax.swing.*;
public class InputListener {
    private String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
