package Quiz.Quiz10;

public class Door {
    private boolean open;

}
