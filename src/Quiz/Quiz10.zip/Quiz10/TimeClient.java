package Quiz.Quiz10;

public interface TimeClient {
    public void Timeout();
}
