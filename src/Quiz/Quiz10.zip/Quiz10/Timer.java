package Quiz.Quiz10;

public class Timer {
}
