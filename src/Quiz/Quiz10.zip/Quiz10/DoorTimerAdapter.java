package Quiz.Quiz10;

public class DoorTimerAdapter implements TimeClient {
    @Override
    public void Timeout() {

    }
}
