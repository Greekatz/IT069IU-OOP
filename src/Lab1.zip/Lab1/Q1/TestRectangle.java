package Lab1.Q1;

public class TestRectangle {

    public static void main(String[] args) {
        Rectangle rec1 = new Rectangle(3,3);
        Rectangle rec2 = new Rectangle(2,5);
        Rectangle rec3 = new Rectangle(5,5);
        Rectangle rec4 = new Rectangle(8, 4);
        Rectangle rec5 = new Rectangle(9, 12);

        rec1.createRec();
        rec2.createRec();
        rec3.createRec();
        rec4.createRec();
        rec5.createRec();
    }
}
