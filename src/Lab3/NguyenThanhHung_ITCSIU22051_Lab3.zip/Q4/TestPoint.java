package Lab3.Q4;

public class TestPoint {
    public static void main(String[] args){
        Point2D point1 = new Point2D(1f, 2f);
        Point3D point2 = new Point3D(0.1f, 0.2f, 0.3f);
        System.out.println(point1.toString());
        System.out.println(point2.toString());
    }
}
