package Lab3.Q1;

import java.awt.Color;
import java.awt.Graphics;
import java.security.SecureRandom;
import javax.swing.JPanel;
public class DrawPanel extends JPanel {
    private SecureRandom randomNumbers = new SecureRandom();
    private MyShape[] shapes = new MyShape[5];

    public DrawPanel() {
        setBackground(Color.WHITE);
        shapes = drawRandomShapes();
    }

    private MyShape[] drawRandomShapes() {
        for (int i = 0; i < shapes.length; i++) {
            int shapeType = randomNumbers.nextInt((3) + 1);
            int x1 = randomNumbers.nextInt(300 + 200);
            int x2 = randomNumbers.nextInt(300 + 200);
            int y1 = randomNumbers.nextInt(300 + 200);
            int y2 = randomNumbers.nextInt(300 + 200);

            Color color = new Color(randomNumbers. nextInt(256),randomNumbers.nextInt(256),
                    randomNumbers.nextInt(256));
            switch (shapeType) {
                case 1:
                    shapes[i] = new MyLine(x1, y1, x2, y2, color);
                    break;
                case 2:
                    shapes[i] = new MyOval(x1, y1, x2, y2, color);
                    break;
                case 3:
                    shapes[i] = new MyRectangle(x1, y1, x2, y2, color);
                    break;
            }

            String type = "";

            if (shapeType == 2) {
                 type = "Oval";
            }

            if (shapeType == 3) {
                 type = "Rectangle";
            }

            if (shapes[i] instanceof MyBoundedShape boundedShape) {
                double area = boundedShape.getArea();
                System.out.println("Area of shape " + type + shapes[i] +": " + area);
            }
        }
        return shapes;
    }

    public void paintComponent(Graphics g) {
        super.paintComponent(g);

        for (MyShape shape : shapes)
            shape.draw(g);
    }


} // end class draw panel
